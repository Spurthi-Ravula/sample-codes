import UIKit

var greeting = "Hello, playground"
print("Hello, Moon!")
var planet = "Mars"
print("My fav planet is " + planet)
print("My fav planet is \(planet)")
var age = 30
//print("Age is" + age)
print("Age is \(age)")

print(1,"Hello",78.9,"😀", terminator: "ss")
print("Hai")
//print(1,2,3,4,5, separator: "*" , "Hello")
let pi = 3.14
print (pi)
/*
 let cannot be re assigned
 */
//pi = 5
//print (pi)


